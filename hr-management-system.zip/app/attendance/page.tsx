"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, Calendar, CheckCircle, XCircle } from "lucide-react"

const attendanceData = [
  {
    id: 1,
    employee: "أحمد محمد",
    date: "2024-01-18",
    checkIn: "09:00",
    checkOut: "17:30",
    status: "حاضر",
    hours: "8.5",
  },
  {
    id: 2,
    employee: "فاطمة علي",
    date: "2024-01-18",
    checkIn: "08:45",
    checkOut: "17:15",
    status: "حاضر",
    hours: "8.5",
  },
  {
    id: 3,
    employee: "محمد حسن",
    date: "2024-01-18",
    checkIn: "-",
    checkOut: "-",
    status: "غائب",
    hours: "0",
  },
]

export default function AttendancePage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">الحضور والانصراف</h1>
          <div className="flex gap-2">
            <Button variant="outline">
              <Calendar className="h-4 w-4 ml-2" />
              طلب إجازة
            </Button>
            <Button className="bg-green-600 hover:bg-green-700">
              <Clock className="h-4 w-4 ml-2" />
              تسجيل الحضور
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">الحضور اليوم</p>
                  <p className="text-2xl font-bold text-green-600">18</p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">الغياب اليوم</p>
                  <p className="text-2xl font-bold text-red-600">3</p>
                </div>
                <XCircle className="h-8 w-8 text-red-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">طلبات الإجازة</p>
                  <p className="text-2xl font-bold text-orange-600">7</p>
                </div>
                <Calendar className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">متوسط الساعات</p>
                  <p className="text-2xl font-bold text-blue-600">8.2</p>
                </div>
                <Clock className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>سجل الحضور اليومي</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-right py-3 px-4 font-medium">الموظف</th>
                    <th className="text-right py-3 px-4 font-medium">التاريخ</th>
                    <th className="text-right py-3 px-4 font-medium">وقت الدخول</th>
                    <th className="text-right py-3 px-4 font-medium">وقت الخروج</th>
                    <th className="text-right py-3 px-4 font-medium">عدد الساعات</th>
                    <th className="text-right py-3 px-4 font-medium">الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {attendanceData.map((record) => (
                    <tr key={record.id} className="border-b hover:bg-gray-50 dark:hover:bg-gray-800">
                      <td className="py-3 px-4 font-medium">{record.employee}</td>
                      <td className="py-3 px-4">{record.date}</td>
                      <td className="py-3 px-4">{record.checkIn}</td>
                      <td className="py-3 px-4">{record.checkOut}</td>
                      <td className="py-3 px-4">{record.hours}</td>
                      <td className="py-3 px-4">
                        <Badge
                          className={
                            record.status === "حاضر"
                              ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                              : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
                          }
                        >
                          {record.status}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
