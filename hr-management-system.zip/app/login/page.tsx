"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Eye, EyeOff, User, Lock, AlertCircle } from "lucide-react"

declare global {
  interface Window {
    electronAPI?: {
      login: (credentials: { username: string; password: string }) => Promise<any>
      isElectron: boolean
    }
  }
}

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  })
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      if (window.electronAPI) {
        // تسجيل الدخول في تطبيق Electron
        const result = await window.electronAPI.login(formData)

        if (result.success) {
          // حفظ بيانات المستخدم في localStorage
          localStorage.setItem("user", JSON.stringify(result.user))
          router.push("/")
        } else {
          setError(result.message || "خطأ في تسجيل الدخول")
        }
      } else {
        // تسجيل الدخول في المتصفح (للتطوير)
        if (formData.username === "admin" && formData.password === "admin123") {
          localStorage.setItem(
            "user",
            JSON.stringify({
              id: 1,
              username: "admin",
              role: "admin",
            }),
          )
          router.push("/")
        } else {
          setError("اسم المستخدم أو كلمة المرور غير صحيحة")
        }
      }
    } catch (error) {
      setError("حدث خطأ أثناء تسجيل الدخول")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-red-600 rounded-full flex items-center justify-center mb-4">
            <span className="text-white font-bold text-xl">HR</span>
          </div>
          <CardTitle className="text-2xl font-bold">نظام إدارة الموارد البشرية</CardTitle>
          <p className="text-gray-600 dark:text-gray-400">OnTime Payroll System</p>
          {window.electronAPI?.isElectron && <p className="text-sm text-green-600">إصدار سطح المكتب</p>}
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-md text-red-700">
                <AlertCircle className="h-4 w-4" />
                <span className="text-sm">{error}</span>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="username">اسم المستخدم</Label>
              <div className="relative">
                <User className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="username"
                  type="text"
                  placeholder="أدخل اسم المستخدم"
                  className="pr-10"
                  value={formData.username}
                  onChange={(e) => setFormData((prev) => ({ ...prev, username: e.target.value }))}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">كلمة المرور</Label>
              <div className="relative">
                <Lock className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="أدخل كلمة المرور"
                  className="pr-10 pl-10"
                  value={formData.password}
                  onChange={(e) => setFormData((prev) => ({ ...prev, password: e.target.value }))}
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute left-0 top-0 h-full px-3 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-400" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-400" />
                  )}
                </Button>
              </div>
            </div>

            <Button type="submit" className="w-full bg-red-600 hover:bg-red-700" disabled={loading}>
              {loading ? "جاري تسجيل الدخول..." : "تسجيل الدخول"}
            </Button>

            <div className="text-center space-y-2">
              <p className="text-sm text-gray-600">
                المستخدم الافتراضي: <strong>admin</strong>
              </p>
              <p className="text-sm text-gray-600">
                كلمة المرور: <strong>admin123</strong>
              </p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
