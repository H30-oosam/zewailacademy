import { AuthGuard } from "@/components/auth-guard"
import { DashboardLayout } from "@/components/dashboard-layout"
import { DashboardStats } from "@/components/dashboard-stats"
import { QuickActions } from "@/components/quick-actions"
import { RecentActivities } from "@/components/recent-activities"

export default function HomePage() {
  return (
    <AuthGuard>
      <DashboardLayout>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">الصفحة الرئيسية</h1>
            <div className="text-sm text-gray-500 dark:text-gray-400">
              آخر تحديث: {new Date().toLocaleDateString("ar-EG")}
            </div>
          </div>

          <DashboardStats />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <QuickActions />
            </div>
            <div>
              <RecentActivities />
            </div>
          </div>
        </div>
      </DashboardLayout>
    </AuthGuard>
  )
}
