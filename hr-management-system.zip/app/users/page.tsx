"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Plus, Search, Edit, Trash2, Eye } from "lucide-react"

const users = [
  {
    id: 1,
    name: "أحمد محمد",
    email: "ahmed@company.com",
    role: "مدير",
    department: "الموارد البشرية",
    status: "نشط",
    joinDate: "2023-01-15",
  },
  {
    id: 2,
    name: "فاطمة علي",
    email: "fatima@company.com",
    role: "موظف",
    department: "المحاسبة",
    status: "نشط",
    joinDate: "2023-03-20",
  },
  {
    id: 3,
    name: "محمد حسن",
    email: "mohamed@company.com",
    role: "موظف",
    department: "التسويق",
    status: "معطل",
    joinDate: "2023-02-10",
  },
]

export default function UsersPage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">إدارة المستخدمين</h1>
          <Button className="bg-red-600 hover:bg-red-700">
            <Plus className="h-4 w-4 ml-2" />
            إضافة مستخدم جديد
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>قائمة المستخدمين</CardTitle>
            <div className="flex items-center space-x-2 space-x-reverse">
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
                <Input placeholder="البحث عن مستخدم..." className="pr-10" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-right py-3 px-4 font-medium">الاسم</th>
                    <th className="text-right py-3 px-4 font-medium">البريد الإلكتروني</th>
                    <th className="text-right py-3 px-4 font-medium">الدور</th>
                    <th className="text-right py-3 px-4 font-medium">القسم</th>
                    <th className="text-right py-3 px-4 font-medium">الحالة</th>
                    <th className="text-right py-3 px-4 font-medium">تاريخ الانضمام</th>
                    <th className="text-right py-3 px-4 font-medium">الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user.id} className="border-b hover:bg-gray-50 dark:hover:bg-gray-800">
                      <td className="py-3 px-4 font-medium">{user.name}</td>
                      <td className="py-3 px-4 text-gray-600 dark:text-gray-400">{user.email}</td>
                      <td className="py-3 px-4">{user.role}</td>
                      <td className="py-3 px-4">{user.department}</td>
                      <td className="py-3 px-4">
                        <Badge
                          className={
                            user.status === "نشط"
                              ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                              : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
                          }
                        >
                          {user.status}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-gray-600 dark:text-gray-400">{user.joinDate}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
