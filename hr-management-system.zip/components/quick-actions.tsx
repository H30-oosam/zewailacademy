"use client"

import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  UserPlus,
  Clock,
  FileText,
  Calendar,
  Briefcase,
  TrendingUp,
  GraduationCap,
  DollarSign,
  Settings,
  Users,
  BarChart3,
  CheckCircle,
} from "lucide-react"

const quickActions = [
  { title: "تسجيل موظف جديد", icon: UserPlus, href: "/users/add", color: "text-blue-600" },
  { title: "تسجيل الحضور", icon: Clock, href: "/attendance", color: "text-green-600" },
  { title: "طلب إجازة", icon: Calendar, href: "/attendance/leave", color: "text-orange-600" },
  { title: "إضافة وظيفة", icon: Briefcase, href: "/recruitment/jobs/add", color: "text-purple-600" },
  { title: "تقييم الأداء", icon: TrendingUp, href: "/performance/evaluations", color: "text-red-600" },
  { title: "إدارة التدريب", icon: GraduationCap, href: "/training/courses", color: "text-indigo-600" },
  { title: "معالجة الرواتب", icon: DollarSign, href: "/payroll", color: "text-yellow-600" },
  { title: "إدارة المستخدمين", icon: Users, href: "/users", color: "text-gray-600" },
  { title: "التقارير", icon: BarChart3, href: "/reports", color: "text-pink-600" },
  { title: "الإعدادات", icon: Settings, href: "/settings", color: "text-gray-500" },
  { title: "الموافقات المعلقة", icon: CheckCircle, href: "/approvals", color: "text-teal-600" },
  { title: "إدارة الأقسام", icon: FileText, href: "/departments", color: "text-cyan-600" },
]

export function QuickActions() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold">الإجراءات السريعة</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => (
            <Link
              key={index}
              href={action.href}
              className="flex flex-col items-center p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
            >
              <action.icon className={`h-8 w-8 mb-2 ${action.color}`} />
              <span className="text-sm font-medium text-center text-gray-700 dark:text-gray-300">{action.title}</span>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
