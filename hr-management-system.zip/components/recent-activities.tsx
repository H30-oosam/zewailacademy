"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, User, Calendar, FileText } from "lucide-react"

const activities = [
  {
    id: 1,
    type: "attendance",
    title: "تسجيل حضور",
    description: "أحمد محمد سجل الحضور",
    time: "9:00 ص",
    status: "success",
    icon: Clock,
  },
  {
    id: 2,
    type: "leave",
    title: "طلب إجازة",
    description: "فاطمة علي طلبت إجازة مرضية",
    time: "8:30 ص",
    status: "pending",
    icon: Calendar,
  },
  {
    id: 3,
    type: "recruitment",
    title: "متقدم جديد",
    description: "تم استلام سيرة ذاتية جديدة",
    time: "8:00 ص",
    status: "info",
    icon: User,
  },
  {
    id: 4,
    type: "evaluation",
    title: "تقييم أداء",
    description: "تم إكمال تقييم محمد أحمد",
    time: "7:45 ص",
    status: "success",
    icon: FileText,
  },
]

const statusColors = {
  success: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
  pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300",
  info: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300",
}

export function RecentActivities() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold">الأنشطة الأخيرة</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-start space-x-3 space-x-reverse">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center">
                  <activity.icon className="h-4 w-4 text-gray-600 dark:text-gray-400" />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">{activity.title}</p>
                  <Badge className={statusColors[activity.status as keyof typeof statusColors]}>
                    {activity.status === "success" && "مكتمل"}
                    {activity.status === "pending" && "معلق"}
                    {activity.status === "info" && "جديد"}
                  </Badge>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{activity.description}</p>
                <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
