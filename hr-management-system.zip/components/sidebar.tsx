"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Home,
  Users,
  Clock,
  Briefcase,
  TrendingUp,
  GraduationCap,
  DollarSign,
  Settings,
  ChevronDown,
  X,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

interface SidebarProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const menuItems = [
  {
    title: "الرئيسية",
    icon: Home,
    href: "/",
  },
  {
    title: "إدارة المستخدمين",
    icon: Users,
    href: "/users",
    submenu: [
      { title: "قائمة المستخدمين", href: "/users" },
      { title: "إضافة مستخدم", href: "/users/add" },
      { title: "الصلاحيات", href: "/users/permissions" },
    ],
  },
  {
    title: "الحضور والانصراف",
    icon: Clock,
    href: "/attendance",
    submenu: [
      { title: "تسجيل الحضور", href: "/attendance" },
      { title: "طلبات الإجازة", href: "/attendance/leave" },
      { title: "تقارير الحضور", href: "/attendance/reports" },
    ],
  },
  {
    title: "نظام التوظيف",
    icon: Briefcase,
    href: "/recruitment",
    submenu: [
      { title: "الوظائف المتاحة", href: "/recruitment/jobs" },
      { title: "المتقدمين", href: "/recruitment/applicants" },
      { title: "المقابلات", href: "/recruitment/interviews" },
    ],
  },
  {
    title: "تقييم الأداء",
    icon: TrendingUp,
    href: "/performance",
    submenu: [
      { title: "التقييمات", href: "/performance/evaluations" },
      { title: "سجلات الأداء", href: "/performance/records" },
      { title: "التقارير", href: "/performance/reports" },
    ],
  },
  {
    title: "التدريب والتعلم",
    icon: GraduationCap,
    href: "/training",
    submenu: [
      { title: "الدورات التدريبية", href: "/training/courses" },
      { title: "التسجيل", href: "/training/enrollment" },
      { title: "تقارير الإنجاز", href: "/training/completion" },
    ],
  },
  {
    title: "المحاسبة والرواتب",
    icon: DollarSign,
    href: "/payroll",
    submenu: [
      { title: "إدارة الرواتب", href: "/payroll" },
      { title: "الإضافات والخصومات", href: "/payroll/adjustments" },
      { title: "تقارير الرواتب", href: "/payroll/reports" },
    ],
  },
  {
    title: "الإعدادات",
    icon: Settings,
    href: "/settings",
  },
]

export function Sidebar({ open, onOpenChange }: SidebarProps) {
  const pathname = usePathname()
  const [expandedItems, setExpandedItems] = useState<string[]>([])

  const toggleExpanded = (title: string) => {
    setExpandedItems((prev) => (prev.includes(title) ? prev.filter((item) => item !== title) : [...prev, title]))
  }

  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" onClick={() => onOpenChange(false)} />
      )}

      {/* Sidebar */}
      <div
        className={cn(
          "fixed top-0 right-0 h-full w-64 bg-gray-800 text-white transform transition-transform duration-300 ease-in-out z-50",
          open ? "translate-x-0" : "translate-x-full lg:translate-x-0",
        )}
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-red-600 rounded flex items-center justify-center">
              <span className="text-white font-bold text-sm">HR</span>
            </div>
            <div>
              <h2 className="font-bold text-lg">OnTime</h2>
              <p className="text-xs text-gray-400">Payroll</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="lg:hidden text-white hover:bg-gray-700"
            onClick={() => onOpenChange(false)}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        <nav className="mt-4 px-2 overflow-y-auto h-[calc(100vh-80px)]">
          {menuItems.map((item) => (
            <div key={item.title} className="mb-1">
              <div className="flex items-center">
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-colors flex-1 gap-3",
                    pathname === item.href
                      ? "bg-red-600 text-white"
                      : "text-gray-300 hover:bg-gray-700 hover:text-white",
                  )}
                >
                  <item.icon className="h-5 w-5" />
                  {item.title}
                </Link>
                {item.submenu && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-gray-300 hover:bg-gray-700 hover:text-white p-1"
                    onClick={() => toggleExpanded(item.title)}
                  >
                    <ChevronDown
                      className={cn("h-4 w-4 transition-transform", expandedItems.includes(item.title) && "rotate-180")}
                    />
                  </Button>
                )}
              </div>

              {item.submenu && expandedItems.includes(item.title) && (
                <div className="mr-8 mt-1 space-y-1">
                  {item.submenu.map((subItem) => (
                    <Link
                      key={subItem.href}
                      href={subItem.href}
                      className={cn(
                        "block px-3 py-2 rounded-lg text-sm transition-colors",
                        pathname === subItem.href
                          ? "bg-red-600 text-white"
                          : "text-gray-400 hover:bg-gray-700 hover:text-white",
                      )}
                    >
                      {subItem.title}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>
      </div>
    </>
  )
}
