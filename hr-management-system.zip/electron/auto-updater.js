const { autoUpdater } = require("electron-updater")
const { dialog } = require("electron")

class AutoUpdater {
  constructor(mainWindow) {
    this.mainWindow = mainWindow
    this.init()
  }

  init() {
    // تكوين التحديث التلقائي
    autoUpdater.checkForUpdatesAndNotify()

    autoUpdater.on("checking-for-update", () => {
      console.log("جاري البحث عن تحديثات...")
    })

    autoUpdater.on("update-available", (info) => {
      console.log("تحديث متوفر:", info.version)
      this.showUpdateDialog(info)
    })

    autoUpdater.on("update-not-available", (info) => {
      console.log("لا توجد تحديثات متوفرة")
    })

    autoUpdater.on("error", (err) => {
      console.error("خطأ في التحديث:", err)
    })

    autoUpdater.on("download-progress", (progressObj) => {
      let log_message = `سرعة التحميل: ${progressObj.bytesPerSecond}`
      log_message += ` - تم تحميل ${progressObj.percent}%`
      log_message += ` (${progressObj.transferred}/${progressObj.total})`
      console.log(log_message)
    })

    autoUpdater.on("update-downloaded", (info) => {
      console.log("تم تحميل التحديث")
      this.showRestartDialog()
    })
  }

  showUpdateDialog(info) {
    dialog
      .showMessageBox(this.mainWindow, {
        type: "info",
        title: "تحديث متوفر",
        message: `الإصدار الجديد ${info.version} متوفر الآن`,
        detail: "هل تريد تحميل وتثبيت التحديث؟",
        buttons: ["نعم", "لاحقاً"],
        defaultId: 0,
      })
      .then((result) => {
        if (result.response === 0) {
          autoUpdater.downloadUpdate()
        }
      })
  }

  showRestartDialog() {
    dialog
      .showMessageBox(this.mainWindow, {
        type: "info",
        title: "إعادة تشغيل مطلوبة",
        message: "تم تحميل التحديث بنجاح",
        detail: "يجب إعادة تشغيل التطبيق لتطبيق التحديث",
        buttons: ["إعادة التشغيل الآن", "لاحقاً"],
        defaultId: 0,
      })
      .then((result) => {
        if (result.response === 0) {
          autoUpdater.quitAndInstall()
        }
      })
  }

  checkForUpdates() {
    autoUpdater.checkForUpdatesAndNotify()
  }
}

module.exports = AutoUpdater
