const builder = require("electron-builder")

builder
  .build({
    targets: builder.Platform.WINDOWS.createTarget(),
    config: {
      appId: "com.hrmanagement.desktop",
      productName: "HR Management System",
      directories: {
        output: "dist",
      },
      files: ["out/**/*", "electron/**/*", "node_modules/**/*"],
      win: {
        target: "nsis",
        icon: "electron/assets/icon.ico",
      },
      nsis: {
        oneClick: false,
        allowToChangeInstallationDirectory: true,
        createDesktopShortcut: true,
        createStartMenuShortcut: true,
        shortcutName: "نظام إدارة الموارد البشرية",
      },
    },
  })
  .then(() => {
    console.log("تم إنشاء ملف التثبيت بنجاح!")
  })
  .catch((error) => {
    console.error("خطأ في إنشاء ملف التثبيت:", error)
  })
