const sqlite3 = require("sqlite3").verbose()
const bcrypt = require("bcryptjs")
const path = require("path")
const { app } = require("electron")

const dbPath = path.join(app.getPath("userData"), "hr_database.db")
let db

function initDatabase() {
  db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
      console.error("خطأ في فتح قاعدة البيانات:", err.message)
    } else {
      console.log("تم الاتصال بقاعدة البيانات بنجاح")
      createTables()
    }
  })
}

function createTables() {
  // جدول المستخدمين
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      email TEXT,
      full_name TEXT,
      role TEXT DEFAULT 'employee',
      department TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `)

  // جدول الحضور
  db.run(`
    CREATE TABLE IF NOT EXISTS attendance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      date DATE,
      check_in TIME,
      check_out TIME,
      status TEXT DEFAULT 'present',
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id)
    )
  `)

  // جدول الإجازات
  db.run(`
    CREATE TABLE IF NOT EXISTS leave_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      start_date DATE,
      end_date DATE,
      leave_type TEXT,
      reason TEXT,
      status TEXT DEFAULT 'pending',
      approved_by INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id),
      FOREIGN KEY (approved_by) REFERENCES users (id)
    )
  `)

  // جدول الرواتب
  db.run(`
    CREATE TABLE IF NOT EXISTS payroll (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      month INTEGER,
      year INTEGER,
      basic_salary DECIMAL(10,2),
      allowances DECIMAL(10,2) DEFAULT 0,
      deductions DECIMAL(10,2) DEFAULT 0,
      net_salary DECIMAL(10,2),
      status TEXT DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id)
    )
  `)

  // إنشاء مستخدم افتراضي (admin)
  createDefaultAdmin()
}

function createDefaultAdmin() {
  const defaultPassword = bcrypt.hashSync("admin123", 10)

  db.run(
    `
    INSERT OR IGNORE INTO users (username, password, full_name, role, email)
    VALUES (?, ?, ?, ?, ?)
  `,
    ["admin", defaultPassword, "مدير النظام", "admin", "admin@company.com"],
    (err) => {
      if (err) {
        console.error("خطأ في إنشاء المستخدم الافتراضي:", err.message)
      } else {
        console.log("تم إنشاء المستخدم الافتراضي: admin / admin123")
      }
    },
  )
}

function authenticateUser(username, password) {
  return new Promise((resolve, reject) => {
    db.get("SELECT * FROM users WHERE username = ?", [username], (err, row) => {
      if (err) {
        reject(err)
      } else if (row && bcrypt.compareSync(password, row.password)) {
        resolve(row)
      } else {
        resolve(null)
      }
    })
  })
}

function createUser(userData) {
  return new Promise((resolve, reject) => {
    const hashedPassword = bcrypt.hashSync(userData.password, 10)

    db.run(
      `
      INSERT INTO users (username, password, full_name, email, role, department)
      VALUES (?, ?, ?, ?, ?, ?)
    `,
      [
        userData.username,
        hashedPassword,
        userData.fullName,
        userData.email,
        userData.role || "employee",
        userData.department,
      ],
      function (err) {
        if (err) {
          reject(err)
        } else {
          resolve(this.lastID)
        }
      },
    )
  })
}

function getAllUsers() {
  return new Promise((resolve, reject) => {
    db.all("SELECT id, username, full_name, email, role, department, created_at FROM users", [], (err, rows) => {
      if (err) {
        reject(err)
      } else {
        resolve(rows)
      }
    })
  })
}

module.exports = {
  initDatabase,
  authenticateUser,
  createUser,
  getAllUsers,
}
