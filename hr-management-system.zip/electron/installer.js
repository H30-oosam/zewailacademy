const { execSync } = require("child_process")
const fs = require("fs")
const path = require("path")

console.log("🚀 بدء عملية إنشاء ملف التثبيت...")

try {
  // التأكد من وجود المجلدات المطلوبة
  if (!fs.existsSync("out")) {
    console.log("📦 بناء التطبيق...")
    execSync("npm run build", { stdio: "inherit" })
  }

  // إنشاء ملف التثبيت
  console.log("🔨 إنشاء ملف التثبيت...")
  execSync("npm run dist-win", { stdio: "inherit" })

  console.log("✅ تم إنشاء ملف التثبيت بنجاح!")
  console.log("📁 يمكنك العثور على ملف التثبيت في مجلد: dist/")

  // عرض الملفات المنشأة
  const distDir = path.join(__dirname, "..", "dist")
  if (fs.existsSync(distDir)) {
    const files = fs.readdirSync(distDir)
    console.log("\n📋 الملفات المنشأة:")
    files.forEach((file) => {
      console.log(`   - ${file}`)
    })
  }
} catch (error) {
  console.error("❌ خطأ في إنشاء ملف التثبيت:", error.message)
  process.exit(1)
}
