const { app, BrowserWindow, ipcMain, dialog, Menu } = require("electron")
const path = require("path")
const isDev = process.env.NODE_ENV === "development"
const { initDatabase, authenticateUser, createUser, getAllUsers } = require("./database")

let mainWindow

// تعطيل قائمة التطبيق الافتراضية
Menu.setApplicationMenu(null)

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, "preload.js"),
      webSecurity: false,
    },
    icon: path.join(__dirname, "assets", "icon.png"),
    titleBarStyle: "default",
    show: false,
    autoHideMenuBar: true,
    frame: true,
  })

  // تحميل التطبيق
  if (isDev) {
    mainWindow.loadURL("http://localhost:3000")
    mainWindow.webContents.openDevTools()
  } else {
    mainWindow.loadFile(path.join(__dirname, "../out/index.html"))
  }

  mainWindow.once("ready-to-show", () => {
    mainWindow.show()

    // عرض رسالة ترحيب
    if (!isDev) {
      dialog.showMessageBox(mainWindow, {
        type: "info",
        title: "مرحباً بك",
        message: "نظام إدارة الموارد البشرية",
        detail: "تم تشغيل التطبيق بنجاح!\n\nبيانات تسجيل الدخول:\nاسم المستخدم: admin\nكلمة المرور: admin123",
        buttons: ["موافق"],
      })
    }
  })

  mainWindow.on("closed", () => {
    mainWindow = null
  })
}

app.whenReady().then(() => {
  // تهيئة قاعدة البيانات
  initDatabase()

  createWindow()

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })
})

app.on("window-all-closed", () => {
  app.quit()
})

// معالجة أحداث المصادقة
ipcMain.handle("login", async (event, { username, password }) => {
  try {
    const user = await authenticateUser(username, password)
    if (user) {
      return {
        success: true,
        user: { id: user.id, username: user.username, role: user.role, full_name: user.full_name },
      }
    } else {
      return { success: false, message: "اسم المستخدم أو كلمة المرور غير صحيحة" }
    }
  } catch (error) {
    return { success: false, message: "خطأ في الخادم" }
  }
})

ipcMain.handle("create-user", async (event, userData) => {
  try {
    const userId = await createUser(userData)
    return { success: true, userId }
  } catch (error) {
    return { success: false, message: error.message }
  }
})

ipcMain.handle("get-users", async () => {
  try {
    const users = await getAllUsers()
    return { success: true, users }
  } catch (error) {
    return { success: false, message: error.message }
  }
})

// معالجة إغلاق التطبيق
ipcMain.handle("quit-app", () => {
  app.quit()
})

// معالجة تصغير النافذة
ipcMain.handle("minimize-window", () => {
  if (mainWindow) {
    mainWindow.minimize()
  }
})

// معالجة تكبير النافذة
ipcMain.handle("maximize-window", () => {
  if (mainWindow) {
    if (mainWindow.isMaximized()) {
      mainWindow.unmaximize()
    } else {
      mainWindow.maximize()
    }
  }
})

// معالجة عرض معلومات التطبيق
ipcMain.handle("show-about", () => {
  dialog.showMessageBox(mainWindow, {
    type: "info",
    title: "حول التطبيق",
    message: "نظام إدارة الموارد البشرية",
    detail: `الإصدار: 1.0.0
تطوير: فريق التطوير
البريد الإلكتروني: support@hrmanagement.com

نظام شامل لإدارة الموارد البشرية والرواتب`,
    buttons: ["موافق"],
  })
})
