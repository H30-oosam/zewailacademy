const { contextBridge, ipcRenderer } = require("electron")

contextBridge.exposeInMainWorld("electronAPI", {
  // المصادقة
  login: (credentials) => ipcRenderer.invoke("login", credentials),

  // إدارة المستخدمين
  createUser: (userData) => ipcRenderer.invoke("create-user", userData),
  getUsers: () => ipcRenderer.invoke("get-users"),

  // التحكم في النافذة
  quitApp: () => ipcRenderer.invoke("quit-app"),
  minimizeWindow: () => ipcRenderer.invoke("minimize-window"),
  maximizeWindow: () => ipcRenderer.invoke("maximize-window"),

  // معلومات النظام
  platform: process.platform,
  isElectron: true,
})
